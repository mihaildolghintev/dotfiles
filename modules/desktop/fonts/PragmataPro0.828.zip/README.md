# PragmataPro

Free and latest PragmataPro from fsd.it (Fabrizio Schiavi). It contains full PragmataPro family. Version is `0.828`.
